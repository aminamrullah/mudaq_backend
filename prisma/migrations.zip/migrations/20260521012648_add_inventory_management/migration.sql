/*
  Warnings:

  - You are about to drop the column `subject_id` on the `kitabs` table. All the data in the column will be lost.

*/
-- DropForeignKey
ALTER TABLE "kitabs" DROP CONSTRAINT "kitabs_subject_id_fkey";

-- AlterTable
ALTER TABLE "exam_schedules" ADD COLUMN     "kitab_id" UUID;

-- AlterTable
ALTER TABLE "kitabs" DROP COLUMN "subject_id";

-- AlterTable
ALTER TABLE "pesantrens" ADD COLUMN     "addon_inventaris" BOOLEAN NOT NULL DEFAULT false,
ADD COLUMN     "addon_koperasi" BOOLEAN NOT NULL DEFAULT false,
ADD COLUMN     "addon_landing_page" BOOLEAN NOT NULL DEFAULT false,
ADD COLUMN     "addon_wa_gateway" BOOLEAN NOT NULL DEFAULT false;

-- AlterTable
ALTER TABLE "question_banks" ADD COLUMN     "kitab_id" UUID;

-- AlterTable
ALTER TABLE "report_cards" ADD COLUMN     "promotion_status" TEXT;

-- AlterTable
ALTER TABLE "students" ADD COLUMN     "kitab_teacher_id" UUID,
ADD COLUMN     "quran_teacher_id" UUID;

-- AlterTable
ALTER TABLE "teachers" ADD COLUMN     "can_manage_kitab" BOOLEAN NOT NULL DEFAULT false,
ADD COLUMN     "can_manage_quran" BOOLEAN NOT NULL DEFAULT false;

-- AlterTable
ALTER TABLE "teaching_journals" ADD COLUMN     "topic" TEXT;

-- CreateTable
CREATE TABLE "inventory_categories" (
    "id" UUID NOT NULL,
    "tenant_uuid" UUID NOT NULL,
    "name" TEXT NOT NULL,
    "description" TEXT,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "inventory_categories_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "inventory_locations" (
    "id" UUID NOT NULL,
    "tenant_uuid" UUID NOT NULL,
    "name" TEXT NOT NULL,
    "description" TEXT,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "inventory_locations_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "inventory_items" (
    "id" UUID NOT NULL,
    "tenant_uuid" UUID NOT NULL,
    "category_id" UUID,
    "location_id" UUID,
    "name" TEXT NOT NULL,
    "code" TEXT,
    "description" TEXT,
    "quantity" INTEGER NOT NULL DEFAULT 1,
    "condition" TEXT NOT NULL DEFAULT 'baik',
    "purchase_date" TIMESTAMP(3),
    "purchase_price" DECIMAL(12,2),
    "source_of_funds" TEXT,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "inventory_items_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "inventory_mutations" (
    "id" UUID NOT NULL,
    "tenant_uuid" UUID NOT NULL,
    "item_id" UUID NOT NULL,
    "type" TEXT NOT NULL,
    "quantity" INTEGER NOT NULL,
    "from_location" TEXT,
    "to_location" TEXT,
    "description" TEXT,
    "created_by" UUID,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "inventory_mutations_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "inventory_categories_tenant_uuid_idx" ON "inventory_categories"("tenant_uuid");

-- CreateIndex
CREATE UNIQUE INDEX "inventory_categories_tenant_uuid_name_key" ON "inventory_categories"("tenant_uuid", "name");

-- CreateIndex
CREATE INDEX "inventory_locations_tenant_uuid_idx" ON "inventory_locations"("tenant_uuid");

-- CreateIndex
CREATE UNIQUE INDEX "inventory_locations_tenant_uuid_name_key" ON "inventory_locations"("tenant_uuid", "name");

-- CreateIndex
CREATE INDEX "inventory_items_tenant_uuid_idx" ON "inventory_items"("tenant_uuid");

-- CreateIndex
CREATE UNIQUE INDEX "inventory_items_tenant_uuid_code_key" ON "inventory_items"("tenant_uuid", "code");

-- CreateIndex
CREATE INDEX "inventory_mutations_tenant_uuid_idx" ON "inventory_mutations"("tenant_uuid");

-- CreateIndex
CREATE INDEX "inventory_mutations_item_id_idx" ON "inventory_mutations"("item_id");

-- AddForeignKey
ALTER TABLE "students" ADD CONSTRAINT "students_quran_teacher_id_fkey" FOREIGN KEY ("quran_teacher_id") REFERENCES "teachers"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "students" ADD CONSTRAINT "students_kitab_teacher_id_fkey" FOREIGN KEY ("kitab_teacher_id") REFERENCES "teachers"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "question_banks" ADD CONSTRAINT "question_banks_kitab_id_fkey" FOREIGN KEY ("kitab_id") REFERENCES "kitabs"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "exam_schedules" ADD CONSTRAINT "exam_schedules_kitab_id_fkey" FOREIGN KEY ("kitab_id") REFERENCES "kitabs"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "inventory_categories" ADD CONSTRAINT "inventory_categories_tenant_uuid_fkey" FOREIGN KEY ("tenant_uuid") REFERENCES "pesantrens"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "inventory_locations" ADD CONSTRAINT "inventory_locations_tenant_uuid_fkey" FOREIGN KEY ("tenant_uuid") REFERENCES "pesantrens"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "inventory_items" ADD CONSTRAINT "inventory_items_tenant_uuid_fkey" FOREIGN KEY ("tenant_uuid") REFERENCES "pesantrens"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "inventory_items" ADD CONSTRAINT "inventory_items_category_id_fkey" FOREIGN KEY ("category_id") REFERENCES "inventory_categories"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "inventory_items" ADD CONSTRAINT "inventory_items_location_id_fkey" FOREIGN KEY ("location_id") REFERENCES "inventory_locations"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "inventory_mutations" ADD CONSTRAINT "inventory_mutations_tenant_uuid_fkey" FOREIGN KEY ("tenant_uuid") REFERENCES "pesantrens"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "inventory_mutations" ADD CONSTRAINT "inventory_mutations_item_id_fkey" FOREIGN KEY ("item_id") REFERENCES "inventory_items"("id") ON DELETE CASCADE ON UPDATE CASCADE;
