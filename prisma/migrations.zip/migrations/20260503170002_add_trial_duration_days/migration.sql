-- AlterTable
ALTER TABLE "pesantrens" ADD COLUMN     "trial_duration_days" INTEGER NOT NULL DEFAULT 14;
