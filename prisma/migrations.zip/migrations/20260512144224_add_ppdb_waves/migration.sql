-- AlterEnum
-- This migration adds more than one value to an enum.
-- With PostgreSQL versions 11 and earlier, this is not possible
-- in a single migration. This can be worked around by creating
-- multiple migrations, each migration adding only one value to
-- the enum.


ALTER TYPE "Role" ADD VALUE 'KEPALA_KOPERASI';
ALTER TYPE "Role" ADD VALUE 'STAF_KOPERASI';

-- AlterTable
ALTER TABLE "pesantrens" ADD COLUMN     "description" TEXT,
ADD COLUMN     "landing_page_config" JSONB DEFAULT '{"primaryColor": "#10b981", "secondaryColor": "#064e3b", "heroTitle": "Selamat Datang", "heroSubtitle": "Membangun Generasi Rabbani", "fontFamily": "Inter"}',
ADD COLUMN     "landing_page_template" TEXT NOT NULL DEFAULT 'MODERN',
ADD COLUMN     "ppdb_is_active" BOOLEAN NOT NULL DEFAULT false;

-- AlterTable
ALTER TABLE "students" ADD COLUMN     "ppdb_wave_id" UUID;

-- AlterTable
ALTER TABLE "users" ADD COLUMN     "koperasi_outlet_id" UUID;

-- CreateTable
CREATE TABLE "koperasi_outlets" (
    "id" UUID NOT NULL,
    "tenant_uuid" UUID NOT NULL,
    "name" TEXT NOT NULL,
    "code" TEXT,
    "address" TEXT,
    "phone" TEXT,
    "is_active" BOOLEAN NOT NULL DEFAULT true,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "koperasi_outlets_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "product_categories" (
    "id" UUID NOT NULL,
    "tenant_uuid" UUID NOT NULL,
    "outlet_id" UUID,
    "name" TEXT NOT NULL,
    "icon" TEXT,
    "is_active" BOOLEAN NOT NULL DEFAULT true,
    "sort_order" INTEGER NOT NULL DEFAULT 0,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "product_categories_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "product_units" (
    "id" UUID NOT NULL,
    "tenant_uuid" UUID NOT NULL,
    "outlet_id" UUID,
    "name" TEXT NOT NULL,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "product_units_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "products" (
    "id" UUID NOT NULL,
    "tenant_uuid" UUID NOT NULL,
    "outlet_id" UUID NOT NULL,
    "category_id" UUID,
    "unit_id" UUID,
    "name" TEXT NOT NULL,
    "sku" TEXT,
    "barcode" TEXT,
    "description" TEXT,
    "price" DECIMAL(12,2) NOT NULL,
    "cost_price" DECIMAL(12,2) NOT NULL DEFAULT 0,
    "margin_percent" DECIMAL(5,2) NOT NULL DEFAULT 0,
    "stock" INTEGER NOT NULL DEFAULT 0,
    "min_stock" INTEGER NOT NULL DEFAULT 5,
    "image_url" TEXT,
    "unit" TEXT NOT NULL DEFAULT 'pcs',
    "supplier_name" TEXT,
    "supplier_phone" TEXT,
    "is_active" BOOLEAN NOT NULL DEFAULT true,
    "track_stock" BOOLEAN NOT NULL DEFAULT true,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "products_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "stock_movements" (
    "id" UUID NOT NULL,
    "tenant_uuid" UUID NOT NULL,
    "outlet_id" UUID NOT NULL,
    "product_id" UUID NOT NULL,
    "type" TEXT NOT NULL,
    "quantity" INTEGER NOT NULL,
    "cost_price" DECIMAL(12,2),
    "stock_before" INTEGER NOT NULL,
    "stock_after" INTEGER NOT NULL,
    "reference" TEXT,
    "supplier_name" TEXT,
    "notes" TEXT,
    "created_by" UUID,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "stock_movements_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "stock_opnames" (
    "id" UUID NOT NULL,
    "tenant_uuid" UUID NOT NULL,
    "outlet_id" UUID NOT NULL,
    "opname_no" TEXT NOT NULL,
    "date" DATE NOT NULL,
    "status" TEXT NOT NULL DEFAULT 'draft',
    "notes" TEXT,
    "created_by" UUID,
    "completed_at" TIMESTAMP(3),
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "stock_opnames_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "stock_opname_items" (
    "id" UUID NOT NULL,
    "opname_id" UUID NOT NULL,
    "product_id" UUID NOT NULL,
    "system_stock" INTEGER NOT NULL,
    "actual_stock" INTEGER NOT NULL,
    "difference" INTEGER NOT NULL,
    "notes" TEXT,

    CONSTRAINT "stock_opname_items_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "promotions" (
    "id" UUID NOT NULL,
    "tenant_uuid" UUID NOT NULL,
    "outlet_id" UUID NOT NULL,
    "name" TEXT NOT NULL,
    "description" TEXT,
    "discount_type" TEXT NOT NULL,
    "discount_value" DECIMAL(12,2) NOT NULL,
    "min_purchase" DECIMAL(12,2) NOT NULL DEFAULT 0,
    "max_discount" DECIMAL(12,2),
    "apply_to" TEXT NOT NULL DEFAULT 'all',
    "start_date" TIMESTAMP(3) NOT NULL,
    "end_date" TIMESTAMP(3) NOT NULL,
    "is_active" BOOLEAN NOT NULL DEFAULT true,
    "usage_limit" INTEGER,
    "usage_count" INTEGER NOT NULL DEFAULT 0,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "promotions_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "promotion_products" (
    "id" UUID NOT NULL,
    "promotion_id" UUID NOT NULL,
    "product_id" UUID NOT NULL,

    CONSTRAINT "promotion_products_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "pos_sessions" (
    "id" UUID NOT NULL,
    "tenant_uuid" UUID NOT NULL,
    "outlet_id" UUID NOT NULL,
    "cashier_id" UUID NOT NULL,
    "opening_balance" DECIMAL(12,2) NOT NULL DEFAULT 0,
    "closing_balance" DECIMAL(12,2),
    "total_sales" DECIMAL(12,2) NOT NULL DEFAULT 0,
    "total_orders" INTEGER NOT NULL DEFAULT 0,
    "opened_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "closed_at" TIMESTAMP(3),
    "notes" TEXT,

    CONSTRAINT "pos_sessions_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "pos_orders" (
    "id" UUID NOT NULL,
    "tenant_uuid" UUID NOT NULL,
    "outlet_id" UUID NOT NULL,
    "order_no" TEXT NOT NULL,
    "order_type" TEXT NOT NULL DEFAULT 'sale',
    "session_id" UUID,
    "student_id" UUID,
    "cashier_id" UUID NOT NULL,
    "bill_id" UUID,
    "subtotal" DECIMAL(12,2) NOT NULL,
    "discount" DECIMAL(12,2) NOT NULL DEFAULT 0,
    "promo_id" UUID,
    "promo_name" TEXT,
    "total" DECIMAL(12,2) NOT NULL,
    "payment_method" TEXT NOT NULL DEFAULT 'wallet',
    "wallet_tx_ref" TEXT,
    "status" TEXT NOT NULL DEFAULT 'completed',
    "notes" TEXT,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "pos_orders_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "pos_order_items" (
    "id" UUID NOT NULL,
    "order_id" UUID NOT NULL,
    "product_id" UUID NOT NULL,
    "product_name" TEXT NOT NULL,
    "quantity" INTEGER NOT NULL,
    "unit_price" DECIMAL(12,2) NOT NULL,
    "cost_price" DECIMAL(12,2) NOT NULL DEFAULT 0,
    "discount" DECIMAL(12,2) NOT NULL DEFAULT 0,
    "subtotal" DECIMAL(12,2) NOT NULL,

    CONSTRAINT "pos_order_items_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "ppdb_waves" (
    "id" UUID NOT NULL,
    "tenant_uuid" UUID NOT NULL,
    "name" TEXT NOT NULL,
    "start_date" TIMESTAMP(3) NOT NULL,
    "end_date" TIMESTAMP(3) NOT NULL,
    "quota" INTEGER NOT NULL DEFAULT 0,
    "is_active" BOOLEAN NOT NULL DEFAULT true,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "ppdb_waves_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "koperasi_outlets_tenant_uuid_idx" ON "koperasi_outlets"("tenant_uuid");

-- CreateIndex
CREATE UNIQUE INDEX "koperasi_outlets_tenant_uuid_name_key" ON "koperasi_outlets"("tenant_uuid", "name");

-- CreateIndex
CREATE INDEX "product_categories_tenant_uuid_idx" ON "product_categories"("tenant_uuid");

-- CreateIndex
CREATE INDEX "product_categories_outlet_id_idx" ON "product_categories"("outlet_id");

-- CreateIndex
CREATE UNIQUE INDEX "product_categories_tenant_uuid_outlet_id_name_key" ON "product_categories"("tenant_uuid", "outlet_id", "name");

-- CreateIndex
CREATE INDEX "product_units_tenant_uuid_idx" ON "product_units"("tenant_uuid");

-- CreateIndex
CREATE INDEX "product_units_outlet_id_idx" ON "product_units"("outlet_id");

-- CreateIndex
CREATE UNIQUE INDEX "product_units_tenant_uuid_outlet_id_name_key" ON "product_units"("tenant_uuid", "outlet_id", "name");

-- CreateIndex
CREATE INDEX "products_tenant_uuid_idx" ON "products"("tenant_uuid");

-- CreateIndex
CREATE INDEX "products_outlet_id_idx" ON "products"("outlet_id");

-- CreateIndex
CREATE INDEX "products_category_id_idx" ON "products"("category_id");

-- CreateIndex
CREATE INDEX "products_unit_id_idx" ON "products"("unit_id");

-- CreateIndex
CREATE UNIQUE INDEX "products_tenant_uuid_sku_key" ON "products"("tenant_uuid", "sku");

-- CreateIndex
CREATE INDEX "stock_movements_tenant_uuid_idx" ON "stock_movements"("tenant_uuid");

-- CreateIndex
CREATE INDEX "stock_movements_outlet_id_idx" ON "stock_movements"("outlet_id");

-- CreateIndex
CREATE INDEX "stock_movements_product_id_idx" ON "stock_movements"("product_id");

-- CreateIndex
CREATE UNIQUE INDEX "stock_opnames_opname_no_key" ON "stock_opnames"("opname_no");

-- CreateIndex
CREATE INDEX "stock_opnames_tenant_uuid_idx" ON "stock_opnames"("tenant_uuid");

-- CreateIndex
CREATE INDEX "stock_opnames_outlet_id_idx" ON "stock_opnames"("outlet_id");

-- CreateIndex
CREATE INDEX "stock_opname_items_opname_id_idx" ON "stock_opname_items"("opname_id");

-- CreateIndex
CREATE UNIQUE INDEX "stock_opname_items_opname_id_product_id_key" ON "stock_opname_items"("opname_id", "product_id");

-- CreateIndex
CREATE INDEX "promotions_tenant_uuid_idx" ON "promotions"("tenant_uuid");

-- CreateIndex
CREATE INDEX "promotions_outlet_id_idx" ON "promotions"("outlet_id");

-- CreateIndex
CREATE UNIQUE INDEX "promotion_products_promotion_id_product_id_key" ON "promotion_products"("promotion_id", "product_id");

-- CreateIndex
CREATE INDEX "pos_sessions_tenant_uuid_idx" ON "pos_sessions"("tenant_uuid");

-- CreateIndex
CREATE INDEX "pos_sessions_outlet_id_idx" ON "pos_sessions"("outlet_id");

-- CreateIndex
CREATE INDEX "pos_sessions_cashier_id_idx" ON "pos_sessions"("cashier_id");

-- CreateIndex
CREATE UNIQUE INDEX "pos_orders_order_no_key" ON "pos_orders"("order_no");

-- CreateIndex
CREATE INDEX "pos_orders_tenant_uuid_idx" ON "pos_orders"("tenant_uuid");

-- CreateIndex
CREATE INDEX "pos_orders_outlet_id_idx" ON "pos_orders"("outlet_id");

-- CreateIndex
CREATE INDEX "pos_orders_student_id_idx" ON "pos_orders"("student_id");

-- CreateIndex
CREATE INDEX "pos_orders_session_id_idx" ON "pos_orders"("session_id");

-- CreateIndex
CREATE INDEX "pos_order_items_order_id_idx" ON "pos_order_items"("order_id");

-- CreateIndex
CREATE INDEX "ppdb_waves_tenant_uuid_idx" ON "ppdb_waves"("tenant_uuid");

-- CreateIndex
CREATE UNIQUE INDEX "ppdb_waves_tenant_uuid_name_key" ON "ppdb_waves"("tenant_uuid", "name");

-- AddForeignKey
ALTER TABLE "users" ADD CONSTRAINT "users_koperasi_outlet_id_fkey" FOREIGN KEY ("koperasi_outlet_id") REFERENCES "koperasi_outlets"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "students" ADD CONSTRAINT "students_ppdb_wave_id_fkey" FOREIGN KEY ("ppdb_wave_id") REFERENCES "ppdb_waves"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "koperasi_outlets" ADD CONSTRAINT "koperasi_outlets_tenant_uuid_fkey" FOREIGN KEY ("tenant_uuid") REFERENCES "pesantrens"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "product_categories" ADD CONSTRAINT "product_categories_tenant_uuid_fkey" FOREIGN KEY ("tenant_uuid") REFERENCES "pesantrens"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "product_categories" ADD CONSTRAINT "product_categories_outlet_id_fkey" FOREIGN KEY ("outlet_id") REFERENCES "koperasi_outlets"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "product_units" ADD CONSTRAINT "product_units_tenant_uuid_fkey" FOREIGN KEY ("tenant_uuid") REFERENCES "pesantrens"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "product_units" ADD CONSTRAINT "product_units_outlet_id_fkey" FOREIGN KEY ("outlet_id") REFERENCES "koperasi_outlets"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "products" ADD CONSTRAINT "products_tenant_uuid_fkey" FOREIGN KEY ("tenant_uuid") REFERENCES "pesantrens"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "products" ADD CONSTRAINT "products_outlet_id_fkey" FOREIGN KEY ("outlet_id") REFERENCES "koperasi_outlets"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "products" ADD CONSTRAINT "products_category_id_fkey" FOREIGN KEY ("category_id") REFERENCES "product_categories"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "products" ADD CONSTRAINT "products_unit_id_fkey" FOREIGN KEY ("unit_id") REFERENCES "product_units"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "stock_movements" ADD CONSTRAINT "stock_movements_tenant_uuid_fkey" FOREIGN KEY ("tenant_uuid") REFERENCES "pesantrens"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "stock_movements" ADD CONSTRAINT "stock_movements_outlet_id_fkey" FOREIGN KEY ("outlet_id") REFERENCES "koperasi_outlets"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "stock_movements" ADD CONSTRAINT "stock_movements_product_id_fkey" FOREIGN KEY ("product_id") REFERENCES "products"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "stock_movements" ADD CONSTRAINT "stock_movements_created_by_fkey" FOREIGN KEY ("created_by") REFERENCES "users"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "stock_opnames" ADD CONSTRAINT "stock_opnames_tenant_uuid_fkey" FOREIGN KEY ("tenant_uuid") REFERENCES "pesantrens"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "stock_opnames" ADD CONSTRAINT "stock_opnames_outlet_id_fkey" FOREIGN KEY ("outlet_id") REFERENCES "koperasi_outlets"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "stock_opname_items" ADD CONSTRAINT "stock_opname_items_opname_id_fkey" FOREIGN KEY ("opname_id") REFERENCES "stock_opnames"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "stock_opname_items" ADD CONSTRAINT "stock_opname_items_product_id_fkey" FOREIGN KEY ("product_id") REFERENCES "products"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "promotions" ADD CONSTRAINT "promotions_tenant_uuid_fkey" FOREIGN KEY ("tenant_uuid") REFERENCES "pesantrens"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "promotions" ADD CONSTRAINT "promotions_outlet_id_fkey" FOREIGN KEY ("outlet_id") REFERENCES "koperasi_outlets"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "promotion_products" ADD CONSTRAINT "promotion_products_promotion_id_fkey" FOREIGN KEY ("promotion_id") REFERENCES "promotions"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "promotion_products" ADD CONSTRAINT "promotion_products_product_id_fkey" FOREIGN KEY ("product_id") REFERENCES "products"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "pos_sessions" ADD CONSTRAINT "pos_sessions_tenant_uuid_fkey" FOREIGN KEY ("tenant_uuid") REFERENCES "pesantrens"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "pos_sessions" ADD CONSTRAINT "pos_sessions_outlet_id_fkey" FOREIGN KEY ("outlet_id") REFERENCES "koperasi_outlets"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "pos_sessions" ADD CONSTRAINT "pos_sessions_cashier_id_fkey" FOREIGN KEY ("cashier_id") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "pos_orders" ADD CONSTRAINT "pos_orders_tenant_uuid_fkey" FOREIGN KEY ("tenant_uuid") REFERENCES "pesantrens"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "pos_orders" ADD CONSTRAINT "pos_orders_outlet_id_fkey" FOREIGN KEY ("outlet_id") REFERENCES "koperasi_outlets"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "pos_orders" ADD CONSTRAINT "pos_orders_session_id_fkey" FOREIGN KEY ("session_id") REFERENCES "pos_sessions"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "pos_orders" ADD CONSTRAINT "pos_orders_student_id_fkey" FOREIGN KEY ("student_id") REFERENCES "students"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "pos_orders" ADD CONSTRAINT "pos_orders_cashier_id_fkey" FOREIGN KEY ("cashier_id") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "pos_order_items" ADD CONSTRAINT "pos_order_items_order_id_fkey" FOREIGN KEY ("order_id") REFERENCES "pos_orders"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "pos_order_items" ADD CONSTRAINT "pos_order_items_product_id_fkey" FOREIGN KEY ("product_id") REFERENCES "products"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "ppdb_waves" ADD CONSTRAINT "ppdb_waves_tenant_uuid_fkey" FOREIGN KEY ("tenant_uuid") REFERENCES "pesantrens"("id") ON DELETE CASCADE ON UPDATE CASCADE;
