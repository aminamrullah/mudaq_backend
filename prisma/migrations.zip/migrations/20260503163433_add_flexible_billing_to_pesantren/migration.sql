-- AlterTable
ALTER TABLE "pesantrens" ADD COLUMN     "billing_type" TEXT NOT NULL DEFAULT 'per_student',
ADD COLUMN     "fixed_billing_amount" DECIMAL(12,2) NOT NULL DEFAULT 0;
