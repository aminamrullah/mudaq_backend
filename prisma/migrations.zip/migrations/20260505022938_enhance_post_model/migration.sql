/*
  Warnings:

  - You are about to drop the column `ayah_from` on the `tahfidz_records` table. All the data in the column will be lost.
  - You are about to drop the column `ayah_to` on the `tahfidz_records` table. All the data in the column will be lost.
  - You are about to drop the column `surah` on the `tahfidz_records` table. All the data in the column will be lost.
  - Added the required column `title` to the `tahfidz_records` table without a default value. This is not possible if the table is not empty.

*/
-- AlterTable
ALTER TABLE "pesantrens" ADD COLUMN     "calendar_type" TEXT NOT NULL DEFAULT 'gregorian';

-- AlterTable
ALTER TABLE "posts" ADD COLUMN     "image_url" TEXT,
ADD COLUMN     "video_url" TEXT;

-- AlterTable
ALTER TABLE "students" ADD COLUMN     "city" TEXT,
ADD COLUMN     "country" TEXT DEFAULT 'Indonesia',
ADD COLUMN     "district" TEXT,
ADD COLUMN     "father_address" TEXT,
ADD COLUMN     "file_akta" TEXT,
ADD COLUMN     "file_ijazah" TEXT,
ADD COLUMN     "file_kk" TEXT,
ADD COLUMN     "file_others" TEXT,
ADD COLUMN     "height" INTEGER,
ADD COLUMN     "last_education" TEXT,
ADD COLUMN     "mother_address" TEXT,
ADD COLUMN     "province" TEXT,
ADD COLUMN     "village" TEXT,
ADD COLUMN     "weight" INTEGER;

-- AlterTable
ALTER TABLE "tahfidz_records" DROP COLUMN "ayah_from",
DROP COLUMN "ayah_to",
DROP COLUMN "surah",
ADD COLUMN     "category" TEXT NOT NULL DEFAULT 'QURAN',
ADD COLUMN     "from" INTEGER,
ADD COLUMN     "title" TEXT NOT NULL,
ADD COLUMN     "to" INTEGER;

-- CreateTable
CREATE TABLE "academic_periods" (
    "id" UUID NOT NULL,
    "tenant_uuid" UUID NOT NULL,
    "academic_year_id" UUID NOT NULL,
    "name" TEXT NOT NULL,
    "start_date" TIMESTAMP(3) NOT NULL,
    "end_date" TIMESTAMP(3) NOT NULL,
    "is_active" BOOLEAN NOT NULL DEFAULT false,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "academic_periods_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "question_banks" (
    "id" UUID NOT NULL,
    "tenant_uuid" UUID NOT NULL,
    "subject_id" UUID NOT NULL,
    "teacher_id" UUID NOT NULL,
    "title" TEXT NOT NULL,
    "description" TEXT,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "question_banks_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "questions" (
    "id" UUID NOT NULL,
    "question_bank_id" UUID NOT NULL,
    "type" TEXT NOT NULL,
    "content" TEXT NOT NULL,
    "options" JSONB,
    "correct_answer" TEXT,
    "points" INTEGER NOT NULL DEFAULT 10,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "questions_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "exams" (
    "id" UUID NOT NULL,
    "tenant_uuid" UUID NOT NULL,
    "academic_year_id" UUID NOT NULL,
    "period_id" UUID,
    "name" TEXT NOT NULL,
    "start_date" TIMESTAMP(3) NOT NULL,
    "end_date" TIMESTAMP(3) NOT NULL,
    "status" TEXT NOT NULL DEFAULT 'draft',
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "exams_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "exam_schedules" (
    "id" UUID NOT NULL,
    "tenant_uuid" UUID NOT NULL,
    "exam_id" UUID NOT NULL,
    "subject_id" UUID NOT NULL,
    "question_bank_id" UUID,
    "classroom_id" UUID NOT NULL,
    "date" DATE NOT NULL,
    "start_time" TEXT NOT NULL,
    "end_time" TEXT NOT NULL,
    "supervisor_id" UUID,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "exam_schedules_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "exam_results" (
    "id" UUID NOT NULL,
    "tenant_uuid" UUID NOT NULL,
    "exam_schedule_id" UUID NOT NULL,
    "student_id" UUID NOT NULL,
    "score" DECIMAL(5,2) NOT NULL,
    "answers" JSONB,
    "notes" TEXT,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "exam_results_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "report_cards" (
    "id" UUID NOT NULL,
    "tenant_uuid" UUID NOT NULL,
    "student_id" UUID NOT NULL,
    "academic_year_id" UUID NOT NULL,
    "period_id" UUID,
    "classroom_id" UUID NOT NULL,
    "total_score" DECIMAL(8,2),
    "average_score" DECIMAL(5,2),
    "rank" INTEGER,
    "notes_homeroom" TEXT,
    "status" TEXT NOT NULL DEFAULT 'draft',
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "report_cards_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "report_card_details" (
    "id" UUID NOT NULL,
    "report_card_id" UUID NOT NULL,
    "subject_id" UUID NOT NULL,
    "score" DECIMAL(5,2) NOT NULL,
    "predicate" TEXT,
    "notes" TEXT,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "report_card_details_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "donation_disbursements" (
    "id" UUID NOT NULL,
    "tenant_uuid" UUID NOT NULL,
    "fee_category_id" UUID NOT NULL,
    "amount" DECIMAL(12,2) NOT NULL,
    "disbursement_date" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "recipient" TEXT,
    "description" TEXT,
    "status" TEXT NOT NULL DEFAULT 'success',
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "donation_disbursements_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "teacher_attendances" (
    "id" UUID NOT NULL,
    "tenant_uuid" UUID NOT NULL,
    "teacher_id" UUID NOT NULL,
    "schedule_id" UUID,
    "date" DATE NOT NULL,
    "status" TEXT NOT NULL,
    "check_in" TIMESTAMP(3),
    "check_out" TIMESTAMP(3),
    "notes" TEXT,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "teacher_attendances_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "teaching_journals" (
    "id" UUID NOT NULL,
    "tenant_uuid" UUID NOT NULL,
    "teacher_id" UUID NOT NULL,
    "schedule_id" UUID NOT NULL,
    "date" DATE NOT NULL,
    "material" TEXT NOT NULL,
    "student_count" INTEGER NOT NULL DEFAULT 0,
    "notes" TEXT,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "teaching_journals_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "academic_periods_tenant_uuid_idx" ON "academic_periods"("tenant_uuid");

-- CreateIndex
CREATE UNIQUE INDEX "academic_periods_tenant_uuid_academic_year_id_name_key" ON "academic_periods"("tenant_uuid", "academic_year_id", "name");

-- CreateIndex
CREATE INDEX "question_banks_tenant_uuid_idx" ON "question_banks"("tenant_uuid");

-- CreateIndex
CREATE INDEX "questions_question_bank_id_idx" ON "questions"("question_bank_id");

-- CreateIndex
CREATE INDEX "exams_tenant_uuid_idx" ON "exams"("tenant_uuid");

-- CreateIndex
CREATE INDEX "exam_schedules_tenant_uuid_idx" ON "exam_schedules"("tenant_uuid");

-- CreateIndex
CREATE INDEX "exam_results_tenant_uuid_idx" ON "exam_results"("tenant_uuid");

-- CreateIndex
CREATE UNIQUE INDEX "exam_results_exam_schedule_id_student_id_key" ON "exam_results"("exam_schedule_id", "student_id");

-- CreateIndex
CREATE INDEX "report_cards_tenant_uuid_idx" ON "report_cards"("tenant_uuid");

-- CreateIndex
CREATE UNIQUE INDEX "report_cards_student_id_academic_year_id_period_id_key" ON "report_cards"("student_id", "academic_year_id", "period_id");

-- CreateIndex
CREATE UNIQUE INDEX "report_card_details_report_card_id_subject_id_key" ON "report_card_details"("report_card_id", "subject_id");

-- CreateIndex
CREATE INDEX "donation_disbursements_tenant_uuid_idx" ON "donation_disbursements"("tenant_uuid");

-- CreateIndex
CREATE INDEX "teacher_attendances_tenant_uuid_idx" ON "teacher_attendances"("tenant_uuid");

-- CreateIndex
CREATE INDEX "teacher_attendances_teacher_id_idx" ON "teacher_attendances"("teacher_id");

-- CreateIndex
CREATE UNIQUE INDEX "teacher_attendances_teacher_id_schedule_id_date_key" ON "teacher_attendances"("teacher_id", "schedule_id", "date");

-- CreateIndex
CREATE INDEX "teaching_journals_tenant_uuid_idx" ON "teaching_journals"("tenant_uuid");

-- CreateIndex
CREATE INDEX "teaching_journals_teacher_id_idx" ON "teaching_journals"("teacher_id");

-- AddForeignKey
ALTER TABLE "academic_periods" ADD CONSTRAINT "academic_periods_tenant_uuid_fkey" FOREIGN KEY ("tenant_uuid") REFERENCES "pesantrens"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "academic_periods" ADD CONSTRAINT "academic_periods_academic_year_id_fkey" FOREIGN KEY ("academic_year_id") REFERENCES "academic_years"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "question_banks" ADD CONSTRAINT "question_banks_tenant_uuid_fkey" FOREIGN KEY ("tenant_uuid") REFERENCES "pesantrens"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "question_banks" ADD CONSTRAINT "question_banks_subject_id_fkey" FOREIGN KEY ("subject_id") REFERENCES "subjects"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "question_banks" ADD CONSTRAINT "question_banks_teacher_id_fkey" FOREIGN KEY ("teacher_id") REFERENCES "teachers"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "questions" ADD CONSTRAINT "questions_question_bank_id_fkey" FOREIGN KEY ("question_bank_id") REFERENCES "question_banks"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "exams" ADD CONSTRAINT "exams_tenant_uuid_fkey" FOREIGN KEY ("tenant_uuid") REFERENCES "pesantrens"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "exams" ADD CONSTRAINT "exams_academic_year_id_fkey" FOREIGN KEY ("academic_year_id") REFERENCES "academic_years"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "exams" ADD CONSTRAINT "exams_period_id_fkey" FOREIGN KEY ("period_id") REFERENCES "academic_periods"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "exam_schedules" ADD CONSTRAINT "exam_schedules_tenant_uuid_fkey" FOREIGN KEY ("tenant_uuid") REFERENCES "pesantrens"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "exam_schedules" ADD CONSTRAINT "exam_schedules_exam_id_fkey" FOREIGN KEY ("exam_id") REFERENCES "exams"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "exam_schedules" ADD CONSTRAINT "exam_schedules_subject_id_fkey" FOREIGN KEY ("subject_id") REFERENCES "subjects"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "exam_schedules" ADD CONSTRAINT "exam_schedules_question_bank_id_fkey" FOREIGN KEY ("question_bank_id") REFERENCES "question_banks"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "exam_schedules" ADD CONSTRAINT "exam_schedules_classroom_id_fkey" FOREIGN KEY ("classroom_id") REFERENCES "classrooms"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "exam_schedules" ADD CONSTRAINT "exam_schedules_supervisor_id_fkey" FOREIGN KEY ("supervisor_id") REFERENCES "teachers"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "exam_results" ADD CONSTRAINT "exam_results_tenant_uuid_fkey" FOREIGN KEY ("tenant_uuid") REFERENCES "pesantrens"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "exam_results" ADD CONSTRAINT "exam_results_exam_schedule_id_fkey" FOREIGN KEY ("exam_schedule_id") REFERENCES "exam_schedules"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "exam_results" ADD CONSTRAINT "exam_results_student_id_fkey" FOREIGN KEY ("student_id") REFERENCES "students"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "report_cards" ADD CONSTRAINT "report_cards_tenant_uuid_fkey" FOREIGN KEY ("tenant_uuid") REFERENCES "pesantrens"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "report_cards" ADD CONSTRAINT "report_cards_student_id_fkey" FOREIGN KEY ("student_id") REFERENCES "students"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "report_cards" ADD CONSTRAINT "report_cards_academic_year_id_fkey" FOREIGN KEY ("academic_year_id") REFERENCES "academic_years"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "report_cards" ADD CONSTRAINT "report_cards_period_id_fkey" FOREIGN KEY ("period_id") REFERENCES "academic_periods"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "report_cards" ADD CONSTRAINT "report_cards_classroom_id_fkey" FOREIGN KEY ("classroom_id") REFERENCES "classrooms"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "report_card_details" ADD CONSTRAINT "report_card_details_report_card_id_fkey" FOREIGN KEY ("report_card_id") REFERENCES "report_cards"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "report_card_details" ADD CONSTRAINT "report_card_details_subject_id_fkey" FOREIGN KEY ("subject_id") REFERENCES "subjects"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "donation_disbursements" ADD CONSTRAINT "donation_disbursements_tenant_uuid_fkey" FOREIGN KEY ("tenant_uuid") REFERENCES "pesantrens"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "donation_disbursements" ADD CONSTRAINT "donation_disbursements_fee_category_id_fkey" FOREIGN KEY ("fee_category_id") REFERENCES "fee_categories"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "teacher_attendances" ADD CONSTRAINT "teacher_attendances_tenant_uuid_fkey" FOREIGN KEY ("tenant_uuid") REFERENCES "pesantrens"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "teacher_attendances" ADD CONSTRAINT "teacher_attendances_teacher_id_fkey" FOREIGN KEY ("teacher_id") REFERENCES "teachers"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "teacher_attendances" ADD CONSTRAINT "teacher_attendances_schedule_id_fkey" FOREIGN KEY ("schedule_id") REFERENCES "schedules"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "teaching_journals" ADD CONSTRAINT "teaching_journals_tenant_uuid_fkey" FOREIGN KEY ("tenant_uuid") REFERENCES "pesantrens"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "teaching_journals" ADD CONSTRAINT "teaching_journals_teacher_id_fkey" FOREIGN KEY ("teacher_id") REFERENCES "teachers"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "teaching_journals" ADD CONSTRAINT "teaching_journals_schedule_id_fkey" FOREIGN KEY ("schedule_id") REFERENCES "schedules"("id") ON DELETE CASCADE ON UPDATE CASCADE;
