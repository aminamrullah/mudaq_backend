-- AlterTable
ALTER TABLE "bills" ADD COLUMN     "notified_at" TIMESTAMP(3);

-- AlterTable
ALTER TABLE "fee_categories" ADD COLUMN     "image_url" TEXT;

-- AlterTable
ALTER TABLE "pesantrens" ADD COLUMN     "qris_fee_is_percent" BOOLEAN NOT NULL DEFAULT false,
ADD COLUMN     "qris_platform_fee" DECIMAL(12,2) NOT NULL DEFAULT 0,
ADD COLUMN     "qris_surcharge_fee" DECIMAL(12,2) NOT NULL DEFAULT 0,
ADD COLUMN     "surcharge_fee" DECIMAL(12,2) NOT NULL DEFAULT 0;

-- AlterTable
ALTER TABLE "topup_logs" ADD COLUMN     "net_amount" DECIMAL(12,2) NOT NULL DEFAULT 0,
ADD COLUMN     "surcharge_fee" DECIMAL(12,2) NOT NULL DEFAULT 0,
ADD COLUMN     "xendit_fee" DECIMAL(12,2) NOT NULL DEFAULT 0;

-- AlterTable
ALTER TABLE "transactions" ADD COLUMN     "net_amount" DECIMAL(12,2) NOT NULL DEFAULT 0,
ADD COLUMN     "surcharge_fee" DECIMAL(12,2) NOT NULL DEFAULT 0,
ADD COLUMN     "xendit_fee" DECIMAL(12,2) NOT NULL DEFAULT 0;

-- CreateTable
CREATE TABLE "expenditures" (
    "id" UUID NOT NULL,
    "tenant_uuid" UUID NOT NULL,
    "title" TEXT NOT NULL,
    "amount" DECIMAL(12,2) NOT NULL,
    "date" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "category" TEXT,
    "description" TEXT,
    "payment_method" TEXT NOT NULL DEFAULT 'cash',
    "attachment_url" TEXT,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "expenditures_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "user_activities" (
    "id" UUID NOT NULL,
    "tenant_uuid" UUID,
    "user_id" UUID NOT NULL,
    "action" TEXT NOT NULL,
    "entity" TEXT,
    "entity_id" TEXT,
    "description" TEXT,
    "ip_address" TEXT,
    "user_agent" TEXT,
    "location" TEXT,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "user_activities_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "problem_tickets" (
    "id" UUID NOT NULL,
    "tenant_uuid" UUID NOT NULL,
    "creator_id" UUID NOT NULL,
    "title" TEXT NOT NULL,
    "description" TEXT NOT NULL,
    "category" TEXT NOT NULL,
    "priority" TEXT NOT NULL DEFAULT 'medium',
    "status" TEXT NOT NULL DEFAULT 'open',
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "problem_tickets_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "problem_ticket_messages" (
    "id" UUID NOT NULL,
    "ticket_id" UUID NOT NULL,
    "sender_id" UUID NOT NULL,
    "message" TEXT NOT NULL,
    "attachment_url" TEXT,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "problem_ticket_messages_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "expenditures_tenant_uuid_idx" ON "expenditures"("tenant_uuid");

-- CreateIndex
CREATE INDEX "user_activities_tenant_uuid_idx" ON "user_activities"("tenant_uuid");

-- CreateIndex
CREATE INDEX "user_activities_user_id_idx" ON "user_activities"("user_id");

-- CreateIndex
CREATE INDEX "problem_tickets_tenant_uuid_idx" ON "problem_tickets"("tenant_uuid");

-- CreateIndex
CREATE INDEX "problem_tickets_creator_id_idx" ON "problem_tickets"("creator_id");

-- CreateIndex
CREATE INDEX "problem_ticket_messages_ticket_id_idx" ON "problem_ticket_messages"("ticket_id");

-- CreateIndex
CREATE INDEX "problem_ticket_messages_sender_id_idx" ON "problem_ticket_messages"("sender_id");

-- AddForeignKey
ALTER TABLE "expenditures" ADD CONSTRAINT "expenditures_tenant_uuid_fkey" FOREIGN KEY ("tenant_uuid") REFERENCES "pesantrens"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "user_activities" ADD CONSTRAINT "user_activities_tenant_uuid_fkey" FOREIGN KEY ("tenant_uuid") REFERENCES "pesantrens"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "user_activities" ADD CONSTRAINT "user_activities_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "problem_tickets" ADD CONSTRAINT "problem_tickets_tenant_uuid_fkey" FOREIGN KEY ("tenant_uuid") REFERENCES "pesantrens"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "problem_tickets" ADD CONSTRAINT "problem_tickets_creator_id_fkey" FOREIGN KEY ("creator_id") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "problem_ticket_messages" ADD CONSTRAINT "problem_ticket_messages_ticket_id_fkey" FOREIGN KEY ("ticket_id") REFERENCES "problem_tickets"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "problem_ticket_messages" ADD CONSTRAINT "problem_ticket_messages_sender_id_fkey" FOREIGN KEY ("sender_id") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
