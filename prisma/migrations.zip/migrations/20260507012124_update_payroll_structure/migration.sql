/*
  Warnings:

  - A unique constraint covering the columns `[payroll_id,user_id]` on the table `payroll_items` will be added. If there are existing duplicate values, this will fail.
  - Added the required column `user_id` to the `payroll_items` table without a default value. This is not possible if the table is not empty.

*/
-- DropForeignKey
ALTER TABLE "payroll_items" DROP CONSTRAINT "payroll_items_teacher_id_fkey";

-- DropIndex
DROP INDEX "payroll_items_payroll_id_teacher_id_key";

-- AlterTable
ALTER TABLE "payroll_items" ADD COLUMN     "user_id" UUID NOT NULL,
ALTER COLUMN "teacher_id" DROP NOT NULL;

-- AlterTable
ALTER TABLE "users" ADD COLUMN     "base_salary" DECIMAL(12,2) NOT NULL DEFAULT 0;

-- CreateIndex
CREATE UNIQUE INDEX "payroll_items_payroll_id_user_id_key" ON "payroll_items"("payroll_id", "user_id");

-- AddForeignKey
ALTER TABLE "payroll_items" ADD CONSTRAINT "payroll_items_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "payroll_items" ADD CONSTRAINT "payroll_items_teacher_id_fkey" FOREIGN KEY ("teacher_id") REFERENCES "teachers"("id") ON DELETE SET NULL ON UPDATE CASCADE;
