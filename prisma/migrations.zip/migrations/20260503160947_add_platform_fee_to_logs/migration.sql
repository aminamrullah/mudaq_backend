-- AlterTable
ALTER TABLE "topup_logs" ADD COLUMN     "platform_fee" DECIMAL(12,2) NOT NULL DEFAULT 0;

-- AlterTable
ALTER TABLE "transactions" ADD COLUMN     "platform_fee" DECIMAL(12,2) NOT NULL DEFAULT 0;
