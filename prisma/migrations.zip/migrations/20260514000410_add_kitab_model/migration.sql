/*
  Warnings:

  - You are about to drop the column `category` on the `subjects` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE "pesantrens" ADD COLUMN     "can_manage_landing_page" BOOLEAN NOT NULL DEFAULT false,
ADD COLUMN     "letterhead" TEXT,
ADD COLUMN     "manual_topup_fee" DECIMAL(12,2) NOT NULL DEFAULT 0;

-- AlterTable
ALTER TABLE "report_cards" ADD COLUMN     "attendance_alpa" INTEGER NOT NULL DEFAULT 0,
ADD COLUMN     "attendance_izin" INTEGER NOT NULL DEFAULT 0,
ADD COLUMN     "attendance_sick" INTEGER NOT NULL DEFAULT 0,
ADD COLUMN     "traits" JSONB;

-- AlterTable
ALTER TABLE "schedules" ADD COLUMN     "kitab_id" UUID;

-- AlterTable
ALTER TABLE "subjects" DROP COLUMN "category",
ADD COLUMN     "category_id" UUID;

-- AlterTable
ALTER TABLE "wallets" ADD COLUMN     "daily_spending_limit" DECIMAL(12,2),
ADD COLUMN     "weekly_spending_limit" DECIMAL(12,2);

-- CreateTable
CREATE TABLE "subject_categories" (
    "id" UUID NOT NULL,
    "tenant_uuid" UUID NOT NULL,
    "name" TEXT NOT NULL,
    "description" TEXT,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "subject_categories_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "kitabs" (
    "id" UUID NOT NULL,
    "tenant_uuid" UUID NOT NULL,
    "subject_id" UUID,
    "name" TEXT NOT NULL,
    "author" TEXT,
    "description" TEXT,
    "is_active" BOOLEAN NOT NULL DEFAULT true,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "kitabs_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "tenant_wallets" (
    "id" UUID NOT NULL,
    "tenant_uuid" UUID NOT NULL,
    "balance" DECIMAL(12,2) NOT NULL DEFAULT 0,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "tenant_wallets_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "tenant_wallet_transactions" (
    "id" UUID NOT NULL,
    "tenant_uuid" UUID NOT NULL,
    "type" TEXT NOT NULL,
    "amount" DECIMAL(12,2) NOT NULL,
    "balance_before" DECIMAL(12,2) NOT NULL,
    "balance_after" DECIMAL(12,2) NOT NULL,
    "reference" TEXT,
    "description" TEXT,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "tenant_wallet_transactions_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "subject_categories_tenant_uuid_idx" ON "subject_categories"("tenant_uuid");

-- CreateIndex
CREATE UNIQUE INDEX "subject_categories_tenant_uuid_name_key" ON "subject_categories"("tenant_uuid", "name");

-- CreateIndex
CREATE INDEX "kitabs_tenant_uuid_idx" ON "kitabs"("tenant_uuid");

-- CreateIndex
CREATE UNIQUE INDEX "kitabs_tenant_uuid_name_key" ON "kitabs"("tenant_uuid", "name");

-- CreateIndex
CREATE UNIQUE INDEX "tenant_wallets_tenant_uuid_key" ON "tenant_wallets"("tenant_uuid");

-- CreateIndex
CREATE INDEX "tenant_wallet_transactions_tenant_uuid_idx" ON "tenant_wallet_transactions"("tenant_uuid");

-- AddForeignKey
ALTER TABLE "subjects" ADD CONSTRAINT "subjects_category_id_fkey" FOREIGN KEY ("category_id") REFERENCES "subject_categories"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "subject_categories" ADD CONSTRAINT "subject_categories_tenant_uuid_fkey" FOREIGN KEY ("tenant_uuid") REFERENCES "pesantrens"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "schedules" ADD CONSTRAINT "schedules_kitab_id_fkey" FOREIGN KEY ("kitab_id") REFERENCES "kitabs"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "kitabs" ADD CONSTRAINT "kitabs_tenant_uuid_fkey" FOREIGN KEY ("tenant_uuid") REFERENCES "pesantrens"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "kitabs" ADD CONSTRAINT "kitabs_subject_id_fkey" FOREIGN KEY ("subject_id") REFERENCES "subjects"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "tenant_wallets" ADD CONSTRAINT "tenant_wallets_tenant_uuid_fkey" FOREIGN KEY ("tenant_uuid") REFERENCES "pesantrens"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "tenant_wallet_transactions" ADD CONSTRAINT "tenant_wallet_transactions_tenant_uuid_fkey" FOREIGN KEY ("tenant_uuid") REFERENCES "pesantrens"("id") ON DELETE CASCADE ON UPDATE CASCADE;
