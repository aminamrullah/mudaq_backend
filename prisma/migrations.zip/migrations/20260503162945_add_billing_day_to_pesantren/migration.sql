-- AlterTable
ALTER TABLE "pesantrens" ADD COLUMN     "billing_day" INTEGER NOT NULL DEFAULT 1;
